
import java.util.*;

/**
 * 
 */
public interface IAdapterEmail {

    /**
     * @param notificacion 
     * @return
     */
    public void enviarMail(Notificacion notificacion);

}