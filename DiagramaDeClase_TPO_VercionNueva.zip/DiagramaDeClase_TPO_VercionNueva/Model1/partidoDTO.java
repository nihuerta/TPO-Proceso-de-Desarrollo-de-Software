
import java.util.*;

/**
 * 
 */
public class partidoDTO {

    /**
     * Default constructor
     */
    public partidoDTO() {
    }

    /**
     * 
     */
    private String deporte;

    /**
     * 
     */
    private int cantJugadores;

    /**
     * 
     */
    private int duracion;

    /**
     * 
     */
    private String zona;

    /**
     * 
     */
    private DateTime hroario;

    /**
     * 
     */
    private EstadoPartido estado;

    /**
     * 
     */
    private void estrategia;

    /**
     * 
     */
    private EstadoPartido estado;

    /**
     * 
     */
    private Usuario administrador;

    /**
     * 
     */
    private <ListUusario> jugadores;

}