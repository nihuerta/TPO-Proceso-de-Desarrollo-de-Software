
import java.util.*;

/**
 * 
 */
public class Cancelado implements EstadoPartido {

    /**
     * Default constructor
     */
    public Cancelado() {
    }

    /**
     * 
     */
    public void validarCondiciones() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void aceptarPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void rechazarPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @param contexto 
     * @return
     */
    public void validarCondiciones(partido contexto) {
        // TODO implement here
        return null;
    }

    /**
     * @param contexto 
     * @return
     */
    public void aceptarPartido(partido contexto) {
        // TODO implement here
        return null;
    }

    /**
     * @param contexto 
     * @return
     */
    public void rechazarPartido(partido contexto) {
        // TODO implement here
        return null;
    }

}