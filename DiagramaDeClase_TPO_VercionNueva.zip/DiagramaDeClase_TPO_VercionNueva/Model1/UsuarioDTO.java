
import java.util.*;

/**
 * 
 */
public class UsuarioDTO {

    /**
     * Default constructor
     */
    public UsuarioDTO() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String correo;

    /**
     * 
     */
    private String contraseña;

    /**
     * 
     */
    private String deporteFav;

    /**
     * 
     */
    private enum nivelDeJuego;

}