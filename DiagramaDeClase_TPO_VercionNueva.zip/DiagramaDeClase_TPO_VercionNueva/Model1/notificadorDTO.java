
import java.util.*;

/**
 * 
 */
public class notificadorDTO {

    /**
     * Default constructor
     */
    public notificadorDTO() {
    }

}