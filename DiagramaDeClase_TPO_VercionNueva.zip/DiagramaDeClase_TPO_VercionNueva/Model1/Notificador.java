
import java.util.*;

/**
 * 
 */
public interface Notificador {

    /**
     * @param notificacion
     */
    public void enviarNotificacion(Notificacion notificacion);

}