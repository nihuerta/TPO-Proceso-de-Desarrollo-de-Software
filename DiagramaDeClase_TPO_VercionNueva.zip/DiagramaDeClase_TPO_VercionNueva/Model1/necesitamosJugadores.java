
import java.util.*;

/**
 * 
 */
public class necesitamosJugadores {

    /**
     * Default constructor
     */
    public necesitamosJugadores() {
    }

    /**
     * 
     */
    public void validarCondiciones() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void aceptarPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void rechazarPartido() {
        // TODO implement here
        return null;
    }

}