
import java.util.*;

/**
 * 
 */
public class PartidoCreacionDTO {

    /**
     * Default constructor
     */
    public PartidoCreacionDTO() {
    }

    /**
     * 
     */
    private String deporte;

    /**
     * 
     */
    private int cantJugadores;

    /**
     * 
     */
    private int duracion;

    /**
     * 
     */
    private String zona;

    /**
     * 
     */
    private DateTime horario;

}