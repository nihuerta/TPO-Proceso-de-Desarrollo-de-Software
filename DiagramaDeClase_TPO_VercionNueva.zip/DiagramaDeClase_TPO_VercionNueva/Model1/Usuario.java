
import java.util.*;

/**
 * 
 */
public class Usuario {

    /**
     * Default constructor
     */
    public Usuario() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String correo;

    /**
     * 
     */
    private String contraseña;

    /**
     * 
     */
    private String deporteFav;

    /**
     * 
     */
    private Enum nivelDeJuego;

    /**
     * 
     */
    public EstadoNivelDeJuego estado;

    /**
     * @param usuario 
     * @return
     */
    public void crearUsuario(usuarioDTO usuario) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void aceptarPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void rechazarPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void cancelarPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @param nuevoEstado 
     * @return
     */
    public void cambiarEstado(EstadoNivelDeJuego nuevoEstado) {
        // TODO implement here
        return null;
    }

}