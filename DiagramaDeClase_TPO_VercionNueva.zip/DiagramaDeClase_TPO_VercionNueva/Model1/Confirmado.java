
import java.util.*;

/**
 * 
 */
public class Confirmado {

    /**
     * Default constructor
     */
    public Confirmado() {
    }

    /**
     * 
     */
    public void validarCondiciones() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void aceptarPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void rechazarPartido() {
        // TODO implement here
        return null;
    }

}