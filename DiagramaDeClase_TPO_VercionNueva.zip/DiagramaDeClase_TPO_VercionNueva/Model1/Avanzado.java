
import java.util.*;

/**
 * 
 */
public class Avanzado implements EstadoNivelDeJuego, EstadoNivelDeJuego, EstadoNivelDeJuego {

    /**
     * Default constructor
     */
    public Avanzado() {
    }

    /**
     * @param contexto 
     * @param partido 
     * @return
     */
    public Boolean puedeUnirse(Usuario contexto, Partido partido) {
        // TODO implement here
        return null;
    }

    /**
     * @param contexto 
     * @return
     */
    public int getNivel(Usuario contexto) {
        // TODO implement here
        return 0;
    }

    /**
     * @param contexto 
     * @return
     */
    public String getNombre(Usuario contexto) {
        // TODO implement here
        return "";
    }

    /**
     * @param contexto 
     * @param partido 
     * @return
     */
    public Boolean puedeUnirse(Usuario contexto, Partido partido) {
        // TODO implement here
        return null;
    }

    /**
     * @param contexto 
     * @return
     */
    public int getNivel(Usuario contexto) {
        // TODO implement here
        return 0;
    }

    /**
     * @param contexto 
     * @return
     */
    public String getNombre(Usuario contexto) {
        // TODO implement here
        return "";
    }

    /**
     * @param contexto 
     * @param partido 
     * @return
     */
    public Boolean puedeUnirse(Usuario contexto, Partido partido) {
        // TODO implement here
        return null;
    }

    /**
     * @param contexto 
     * @return
     */
    public int getNivel(Usuario contexto) {
        // TODO implement here
        return 0;
    }

    /**
     * @param contexto 
     * @return
     */
    public String getNombre(Usuario contexto) {
        // TODO implement here
        return "";
    }

    /**
     * @param contexto 
     * @param partido 
     * @return
     */
    public Boolean puedeUnirse(Usuario contexto, Partido partido) {
        // TODO implement here
        return null;
    }

    /**
     * @param contexto 
     * @return
     */
    public int getNivel(Usuario contexto) {
        // TODO implement here
        return 0;
    }

    /**
     * @param contexto 
     * @return
     */
    public String getNombre(Usuario contexto) {
        // TODO implement here
        return "";
    }

}