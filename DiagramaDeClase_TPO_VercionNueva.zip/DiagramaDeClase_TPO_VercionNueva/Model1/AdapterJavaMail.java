
import java.util.*;

/**
 * 
 */
public class AdapterJavaMail implements IAdapterEmail {

    /**
     * Default constructor
     */
    public AdapterJavaMail() {
    }

    /**
     * @param notificacion 
     * @return
     */
    public void enviarEmail(Notificacion notificacion) {
        // TODO implement here
        return null;
    }

    /**
     * @param notificacion 
     * @return
     */
    public void enviarMail(Notificacion notificacion) {
        // TODO implement here
        return null;
    }

}