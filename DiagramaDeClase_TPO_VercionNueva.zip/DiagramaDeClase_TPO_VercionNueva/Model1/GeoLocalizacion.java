
import java.util.*;

/**
 * 
 */
public class GeoLocalizacion {

    /**
     * Default constructor
     */
    public GeoLocalizacion() {
    }

    /**
     * 
     */
    private Double latitud;

    /**
     * 
     */
    private Double longitud;

    /**
     * 
     */
    public void obtenerCoordenadas() {
        // TODO implement here
    }

}