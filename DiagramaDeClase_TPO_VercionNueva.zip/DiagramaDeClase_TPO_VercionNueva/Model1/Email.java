
import java.util.*;

/**
 * 
 */
public class Email {

    /**
     * Default constructor
     */
    public Email() {
    }

    /**
     * 
     */
    private IAdapterEmail adapter;

    /**
     * @param notificacion 
     * @return
     */
    public void enviarNotificacion(Notificacion notificacion) {
        // TODO implement here
        return null;
    }

}