
import java.util.*;

/**
 * 
 */
public class EstrategiaCompuesta {

    /**
     * Default constructor
     */
    public EstrategiaCompuesta() {
    }

    /**
     * 
     */
    private List<EstartegiaEmparejador> Estrategias;

    /**
     * @return
     */
    public List<Usuario> Emparejar() {
        // TODO implement here
        return null;
    }

    /**
     * @param estategia 
     * @return
     */
    public Void AgregarEstrategia(EstategiaEmparejador estategia) {
        // TODO implement here
        return null;
    }

    /**
     * @param estategia 
     * @return
     */
    public Void EliminarEstategia(EstategiaEmparejador estategia) {
        // TODO implement here
        return null;
    }

}