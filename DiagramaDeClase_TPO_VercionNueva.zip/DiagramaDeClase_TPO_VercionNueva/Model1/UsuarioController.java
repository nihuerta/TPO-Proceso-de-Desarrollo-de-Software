
import java.util.*;

/**
 * 
 */
public class UsuarioController {

    /**
     * Default constructor
     */
    public UsuarioController() {
    }

    /**
     * @param usuario 
     * @return
     */
    public void crearUsuario(UsuarioDTO usuario) {
        // TODO implement here
        return null;
    }

}