
import java.util.*;

/**
 * 
 */
public class notificiacionCorreoAdapter {

    /**
     * Default constructor
     */
    public notificiacionCorreoAdapter() {
    }

}