
import java.util.*;

/**
 * 
 */
public class EstrategiaNivel implements EstrategiaEmparejador {

    /**
     * Default constructor
     */
    public EstrategiaNivel() {
    }

    /**
     * @return
     */
    public List<Usuario> Emparejar(List<Usuario>)() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void Emparejar(List<Usuario>)() {
        // TODO implement here
    }

    /**
     * @return
     */
    public List<Usuario> Emparejar() {
        // TODO implement here
        return null;
    }

}