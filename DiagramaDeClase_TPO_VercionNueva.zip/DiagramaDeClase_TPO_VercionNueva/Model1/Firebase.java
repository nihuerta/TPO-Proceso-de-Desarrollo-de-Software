
import java.util.*;

/**
 * 
 */
public class Firebase {

    /**
     * Default constructor
     */
    public Firebase() {
    }

    /**
     * @param notificacion 
     * @return
     */
    public void enviarNotificacion(Notificacion notificacion) {
        // TODO implement here
        return null;
    }

}