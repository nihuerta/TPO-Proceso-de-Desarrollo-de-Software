
import java.util.*;

/**
 * 
 */
public class adapter a javamail {

    /**
     * Default constructor
     */
    public adapter a javamail() {
    }

}