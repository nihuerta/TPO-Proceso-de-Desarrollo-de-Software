
import java.util.*;

/**
 * 
 */
public interface EstadoNivelDeJuego {

    /**
     * @param contexto 
     * @param partido 
     * @return
     */
    public Boolean puedeUnirse(Usuario contexto, Partido partido);

    /**
     * @param contexto 
     * @return
     */
    public int getNivel(Usuario contexto);

    /**
     * @param contexto 
     * @return
     */
    public String getNombre(Usuario contexto);

}