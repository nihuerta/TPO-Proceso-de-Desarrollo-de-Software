
import java.util.*;

/**
 * 
 */
public class EstrategiaCercania implements EstrategiaEmparejador {

    /**
     * Default constructor
     */
    public EstrategiaCercania() {
    }

    /**
     * 
     */
    private String zona;

    /**
     * @param zona String 
     * @return
     */
    public List<Usuario> Emparejar(void zona String) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<Usuario> Emparejar() {
        // TODO implement here
        return null;
    }

}