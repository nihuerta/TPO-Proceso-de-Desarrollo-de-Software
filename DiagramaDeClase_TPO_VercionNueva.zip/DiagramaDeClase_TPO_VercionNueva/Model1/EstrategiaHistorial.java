
import java.util.*;

/**
 * 
 */
public class EstrategiaHistorial implements EstrategiaEmparejador {

    /**
     * Default constructor
     */
    public EstrategiaHistorial() {
    }

    /**
     * 
     */
    private String nivel;

    /**
     * @return
     */
    public List<Usuario> Emparejar() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public List<Usuario> Emparejar() {
        // TODO implement here
        return null;
    }

}