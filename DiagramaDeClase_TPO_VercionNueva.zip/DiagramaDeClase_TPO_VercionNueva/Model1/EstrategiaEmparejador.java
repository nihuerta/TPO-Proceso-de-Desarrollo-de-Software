
import java.util.*;

/**
 * 
 */
public interface EstrategiaEmparejador {

    /**
     * @return
     */
    public List<Usuario> Emparejar();

}