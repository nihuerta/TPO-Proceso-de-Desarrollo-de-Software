
import java.util.*;

/**
 * 
 */
public class PartidoController {

    /**
     * Default constructor
     */
    public PartidoController() {
    }

    /**
     * @param partido 
     * @return
     */
    public Partido crearPartido(partidoDTO partido) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public EstadoPartido getEstadoPartido() {
        // TODO implement here
        return null;
    }

    /**
     * @param estado 
     * @return
     */
    public void setEstadoPartido(EstadoPartido estado) {
        // TODO implement here
        return null;
    }

    /**
     * @param estrategia 
     * @return
     */
    public void setEstategia(EstrategiaEmarejador estrategia) {
        // TODO implement here
        return null;
    }

    /**
     * @param usuario 
     * @return
     */
    public void agregarJugador(Usuario usuario) {
        // TODO implement here
        return null;
    }

}