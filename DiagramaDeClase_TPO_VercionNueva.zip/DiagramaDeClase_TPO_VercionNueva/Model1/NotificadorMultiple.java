
import java.util.*;

/**
 * 
 */
public class NotificadorMultiple {

    /**
     * Default constructor
     */
    public NotificadorMultiple() {
    }

    /**
     * 
     */
    private Notificador email;

    /**
     * 
     */
    private Notificador firebase;

    /**
     * @param Usuario
     */
    public void enviarNotificacion(void Usuario) {
        // TODO implement here
    }

}