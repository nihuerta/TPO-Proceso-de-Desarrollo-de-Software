
import java.util.*;

/**
 * 
 */
public class NotificacionPushAdapter {

    /**
     * Default constructor
     */
    public NotificacionPushAdapter() {
    }

}