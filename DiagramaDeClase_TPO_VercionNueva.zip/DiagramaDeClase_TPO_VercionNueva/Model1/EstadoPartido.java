
import java.util.*;

/**
 * 
 */
public interface EstadoPartido {

    /**
     * @param contexto 
     * @return
     */
    public void validarCondiciones(partido contexto);

    /**
     * @param contexto 
     * @return
     */
    public void aceptarPartido(partido contexto);

    /**
     * @param contexto 
     * @return
     */
    public void rechazarPartido(partido contexto);

}