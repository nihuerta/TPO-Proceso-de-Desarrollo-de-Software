
import java.util.*;

/**
 * 
 */
public class Notificacion {

    /**
     * Default constructor
     */
    public Notificacion() {
    }

    /**
     * 
     */
    private String mensaje;

    /**
     * 
     */
    private String emailRemitente;

    /**
     * 
     */
    private String emailDestinatario;

    /**
     * 
     */
    private String numeroRemitente;

    /**
     * 
     */
    private String numeroDestinatario;

    /**
     * @param type 
     * @return
     */
    public type method(void type) {
        // TODO implement here
        return null;
    }

}