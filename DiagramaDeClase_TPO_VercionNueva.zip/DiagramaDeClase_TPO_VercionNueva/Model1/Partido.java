
import java.util.*;

/**
 * 
 */
public class Partido {

    /**
     * Default constructor
     */
    public Partido() {
    }

    /**
     * 
     */
    private void deporte: String;

    /**
     * 
     */
    private int cantJugadores;

    /**
     * 
     */
    private int duracion;

    /**
     * 
     */
    private String zona;

    /**
     * 
     */
    private DateTime horario;

    /**
     * 
     */
    private EstadoPartido estado;

    /**
     * 
     */
    private Usuario administrador;

    /**
     * 
     */
    private void estrategia: EstategiaEmparejador;

    /**
     * 
     */
    private List<Usuario> jugadores;

    /**
     * 
     */
    public EstadoNivelDeJuego nivelMinimo;

    /**
     * 
     */
    public EstadoNivelDeJuego nivelMaximo;

    /**
     * 
     */
    public boolean permitirCualquierNivel;

    /**
     * @param partido 
     * @return
     */
    public Partido crearPartido(partidoDTO partido) {
        // TODO implement here
        return null;
    }

    /**
     * @param nuevoEstado 
     * @return
     */
    public void cambiarEstado(EstadoPartido nuevoEstado) {
        // TODO implement here
        return null;
    }

    /**
     * @param usuario 
     * @return
     */
    public void agregarJugador(Usuario usuario) {
        // TODO implement here
        return null;
    }

    /**
     * @param estartegia 
     * @return
     */
    public Void setEstartegiaEmparejamiento(void estartegia) {
        // TODO implement here
        return null;
    }

    /**
     * @param nivel 
     * @return
     */
    public boolean permitirJugador(EstadoNivelDeJuego nivel) {
        // TODO implement here
        return false;
    }

}